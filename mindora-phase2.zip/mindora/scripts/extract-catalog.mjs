// Reads the ORIGINAL schedule page (read-only) and writes data/catalog.json + data/source-manifest.json.
// Usage: node scripts/extract-catalog.mjs [path-to-html] [out-dir]
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import vm from 'node:vm';

const src = process.argv[2] ?? 'legacy/mostafa-schedule.html';
const outDir = process.argv[3] ?? 'data';
const bytes = readFileSync(src); // read only: the source file is never written
const text = bytes.toString('utf8');

const dataLine = text.split('\n').find((l) => l.startsWith('var DATA = '));
if (!dataLine) throw new Error('DATA line not found in source');
const data = JSON.parse(dataLine.replace(/^var DATA = /, '').replace(/;\s*$/, ''));

const evMatch = text.match(/var EVENTS=(\[[\s\S]*?\]);/);
if (!evMatch) throw new Error('EVENTS not found in source');
const events = JSON.parse(JSON.stringify(vm.runInNewContext('(' + evMatch[1] + ')')));

const key = (re) => {
  const m = text.match(re);
  if (!m) throw new Error('storage key not found: ' + re);
  return m[1];
};
const storageKeys = {
  done: key(/var KEY = '([^']+)'/),
  notes: key(/NKEY='([^']+)'/),
  grades: key(/GKEY='([^']+)'/),
};

const tasks = data.days.flatMap((d) => d.slots.flatMap((s) => s.tasks));
const manifest = {
  source: { file: src.split('/').pop(), bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') },
  counts: {
    subjects: Object.keys(data.subj).length,
    days: data.days.length,
    slots: data.days.reduce((n, d) => n + d.slots.length, 0),
    tasks: tasks.length,
    lessons: Object.values(data.lessons).reduce((n, a) => n + a.length, 0),
    events: events.length,
    fixedEntries: data.days.reduce((n, d) => n + d.fixed.length, 0),
  },
  storageKeys,
  examDate: data.exam,
};

mkdirSync(outDir, { recursive: true });
writeFileSync(outDir + '/catalog.json', JSON.stringify({ formatVersion: 1, data, events }, null, 1));
writeFileSync(outDir + '/source-manifest.json', JSON.stringify(manifest, null, 2));
console.log(JSON.stringify(manifest, null, 2));
