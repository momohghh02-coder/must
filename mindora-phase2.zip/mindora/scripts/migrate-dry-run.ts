// Dry run: reads a legacy backup file (READ-ONLY), imports it into a throwaway in-memory
// database, verifies, and writes out/migration-report.json. Nothing is ever written back
// to the backup file or to the legacy page.
// Usage: node scripts/migrate-dry-run.ts <backup.json>
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { MemoryStore } from '../src/storage/store.ts';
import { importLegacy } from '../src/migration/legacy.ts';
import { exportLegacy } from '../src/migration/verify.ts';
import { canonicalStringify } from '../src/migration/util.ts';

const file = process.argv[2];
if (!file) { console.error('usage: node scripts/migrate-dry-run.ts <backup.json>'); process.exit(2); }
const root = new URL('..', import.meta.url).pathname;
const catalog = JSON.parse(readFileSync(root + 'data/catalog.json', 'utf8'));
const text = readFileSync(file, 'utf8');

const store = new MemoryStore();
const res = await importLegacy(store, catalog, text);
const r = res.report;
const back = await exportLegacy(store);
const input = JSON.parse(text);
const src = r.sourceKind === 'app-export' ? input : {
  done: JSON.parse(input['mostafa-plan-v1'] ?? '{}'), notes: JSON.parse(input['mostafa-notes-v1'] ?? '{}'), grades: JSON.parse(input['mostafa-grades-v1'] ?? '[]'),
};
const trueDone = Object.fromEntries(Object.entries(src.done ?? {}).filter(([, v]) => v));
const roundTrip = r.unmigratable.length === 0 && canonicalStringify(back) === canonicalStringify({ done: Object.fromEntries(Object.keys(trueDone).map((k) => [k, true])), notes: src.notes ?? {}, grades: src.grades ?? [] });

mkdirSync('out', { recursive: true });
writeFileSync('out/migration-report.json', JSON.stringify(res, null, 2));
console.log(`source: ${r.sourceKind}`);
for (const s of ['done', 'notes', 'grades'] as const) console.log(`${s}:`, JSON.stringify(r.counts[s]));
console.log('unmigratable (kept & reported):', r.unmigratable.length, '| warnings:', r.warnings.length, '| conflicts:', r.conflicts.length);
for (const c of r.verification) console.log(c.ok ? 'PASS' : 'FAIL', c.name, '-', c.detail);
console.log('round trip identical to input:', roundTrip);
console.log('report written to out/migration-report.json');
