import type {
  Subject, Lesson, Task, Day, ScheduleEvent, Plan, Completion, Grade, DailyNote, ImportBatch,
} from '../domain/types.ts';

export interface Tables {
  subjects: Subject;
  lessons: Lesson;
  tasks: Task;
  days: Day;
  events: ScheduleEvent;
  plans: Plan;
  completions: Completion;
  grades: Grade;
  notes: DailyNote;
  imports: ImportBatch;
}
export type TableName = keyof Tables;

// Primary key field per table. A future IndexedDB (Dexie) schema is exactly this list.
export const PRIMARY_KEY: { [K in TableName]: string } = {
  subjects: 'id',
  lessons: 'id',
  tasks: 'id',
  days: 'date',
  events: 'id',
  plans: 'id',
  completions: 'taskId',
  grades: 'id',
  notes: 'date',
  imports: 'id',
};

export interface Store {
  get<K extends TableName>(table: K, key: string): Promise<Tables[K] | undefined>;
  put<K extends TableName>(table: K, row: Tables[K]): Promise<void>;
  all<K extends TableName>(table: K): Promise<Tables[K][]>;
  // All-or-nothing: if fn throws, every write made inside is rolled back.
  transaction<T>(fn: () => Promise<T>): Promise<T>;
}

export class MemoryStore implements Store {
  tables: Map<string, Map<string, unknown>> = new Map();

  constructor() {
    for (const t of Object.keys(PRIMARY_KEY)) this.tables.set(t, new Map());
  }

  async get<K extends TableName>(table: K, key: string) {
    return this.tables.get(table)!.get(key) as Tables[K] | undefined;
  }

  async put<K extends TableName>(table: K, row: Tables[K]) {
    const pk = PRIMARY_KEY[table];
    const key = (row as Record<string, unknown>)[pk];
    if (typeof key !== 'string' || key === '') throw new Error(`bad primary key for ${table}`);
    this.tables.get(table)!.set(key, structuredClone(row));
  }

  async all<K extends TableName>(table: K) {
    return [...this.tables.get(table)!.values()].map((r) => structuredClone(r)) as Tables[K][];
  }

  async transaction<T>(fn: () => Promise<T>): Promise<T> {
    const snapshot = new Map<string, Map<string, unknown>>();
    for (const [t, m] of this.tables) snapshot.set(t, new Map(m));
    try {
      return await fn();
    } catch (e) {
      this.tables = snapshot; // rollback
      throw e;
    }
  }
}
