import type { Check, Conflict } from '../domain/types.ts';
import type { Store } from '../storage/store.ts';
import { rebuildLegacy, type CatalogFile, type CatalogRecords } from './catalog.ts';
import type { MigrationPlan } from './legacy.ts';
import { canonicalStringify, deepEqual, sha256Hex } from './util.ts';

const ok = (name: string, detail = ''): Check => ({ name, ok: true, detail });
const bad = (name: string, detail: string): Check => ({ name, ok: false, detail });
const check = (name: string, pass: boolean, detail = ''): Check => (pass ? ok(name, detail) : bad(name, detail));

export async function readCatalogRecords(store: Store): Promise<CatalogRecords> {
  const plan = await store.get('plans', 'plan');
  if (!plan) throw new Error('no plan in store');
  return {
    plan,
    subjects: await store.all('subjects'),
    lessons: await store.all('lessons'),
    tasks: await store.all('tasks'),
    days: await store.all('days'),
    events: await store.all('events'),
  };
}

// The stored plan must rebuild to EXACTLY the original DATA (no field lost or changed).
export async function verifyCatalogInStore(store: Store, catalog: CatalogFile): Promise<Check[]> {
  const rebuilt = rebuildLegacy(await readCatalogRecords(store));
  return [
    check('catalog.data == original', deepEqual(rebuilt.data, catalog.data), 'rebuilt DATA compared field by field'),
    check('catalog.events == original', deepEqual(rebuilt.events, catalog.events)),
  ];
}

export async function verifyBatch(
  store: Store, _catalog: CatalogFile, plan: MigrationPlan, batchId: string, conflicts: Conflict[],
): Promise<Check[]> {
  const out: Check[] = [];

  // 1. accounting: every input entry is migrated, ignored-false, or reported. Nothing vanishes.
  for (const sec of ['done', 'notes', 'grades'] as const) {
    const c = plan.counts[sec];
    const sum = c.migrated + c.ignoredFalse + c.unmigratable;
    out.push(check(`accounting.${sec}`, sum === c.input, `input ${c.input} = migrated ${c.migrated} + ignoredFalse ${c.ignoredFalse} + unmigratable ${c.unmigratable}`));
  }

  // 2. every planned row exists in the store with identical content
  let missing = 0;
  for (const c of plan.completions) if (!(await store.get('completions', c.taskId))) missing++;
  out.push(check('completions present', missing === 0, `${plan.completions.length} planned, ${missing} missing`));

  const noteConf = new Set(conflicts.filter((c) => c.kind === 'note').map((c) => c.key));
  let noteBad = 0;
  for (const n of plan.notes) {
    if (noteConf.has(n.date)) continue;
    if ((await store.get('notes', n.date))?.text !== n.text) noteBad++;
  }
  out.push(check('notes identical', noteBad === 0, `${plan.notes.length} planned, ${noteBad} differ, ${noteConf.size} reported as conflicts`));

  const gradeConf = new Set(conflicts.filter((c) => c.kind === 'grade').map((c) => c.key));
  let gradeBad = 0;
  for (const g of plan.grades) {
    if (gradeConf.has(g.id)) continue;
    const cur = await store.get('grades', g.id);
    if (!cur || !deepEqual({ ...cur, batchId: null }, { ...g, batchId: null })) gradeBad++;
  }
  out.push(check('grades identical', gradeBad === 0, `${plan.grades.length} planned, ${gradeBad} differ, ${gradeConf.size} reported as conflicts`));

  // 3. the untouched original input is stored and matches its hash
  const batch = await store.get('imports', batchId);
  const hashOk = !!batch && (await sha256Hex(canonicalStringify(batch.raw))) === batchId;
  out.push(check('raw snapshot preserved', hashOk, 'stored input re-hashes to the batch id'));
  return out;
}

// Rebuilds the legacy { done, notes, grades } shape from the store.
// For a single clean import this must equal the original input (round trip).
export async function exportLegacy(store: Store) {
  const done: Record<string, true> = {};
  for (const c of await store.all('completions')) done[c.taskId] = true;
  const notes: Record<string, string> = {};
  for (const n of await store.all('notes')) notes[n.date] = n.text;
  const grades = (await store.all('grades'))
    .sort((a, b) => a.seq - b.seq)
    .map((g) => ({ id: g.legacyId, subj: g.subjectId, name: g.name, score: g.score, max: g.max, date: g.date }));
  return { done, notes, grades };
}
