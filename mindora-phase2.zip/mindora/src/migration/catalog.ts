import type { Subject, Lesson, Task, Day, ScheduleEvent, Plan, TaskKind, LessonOrigin } from '../domain/types.ts';

// ---- shapes of the legacy DATA object (as found in mostafa-schedule.html) ----
export interface LegacyTask {
  id: string; subj: string; title: string; meta: string; kind: string; min: number;
  lesson: string | null; opt?: boolean;
}
export interface LegacySlot { t: string; tasks: LegacyTask[]; brk?: boolean }
export interface LegacyDay {
  date: string; dow: string; dnum: number; mon: string; fixed: string[]; slots: LegacySlot[]; phase: string;
}
export interface LegacyLesson { id: string; title: string; status: string; meta: string; date: string }
export interface LegacyData {
  subj: Record<string, string>;
  days: LegacyDay[];
  lessons: Record<string, LegacyLesson[]>;
  exam: string;
}
export interface LegacyEvent { d: number; h: number; m: number; l: string; lv: number }
export interface CatalogFile { formatVersion: number; data: LegacyData; events: LegacyEvent[] }

export interface CatalogRecords {
  plan: Plan;
  subjects: Subject[];
  lessons: Lesson[];
  tasks: Task[];
  days: Day[];
  events: ScheduleEvent[];
}

const TASK_KINDS = ['backlog', 'new', 'review', 'final', 'course', 'optional'];
const LESSON_ORIGINS = ['backlog', 'new'];

export function buildCatalogRecords(cat: CatalogFile): CatalogRecords {
  const { data, events } = cat;
  const subjectIds = Object.keys(data.subj);
  const subjects: Subject[] = subjectIds.map((id, i) => ({
    id, name: data.subj[id]!, order: i, color: null, icon: null,
  }));

  const tasks: Task[] = [];
  const days: Day[] = [];
  const lessonTask: Record<string, string> = {};

  for (const d of data.days) {
    const slots = d.slots.map((s, slotIndex) => {
      s.tasks.forEach((t, order) => {
        if (!TASK_KINDS.includes(t.kind)) throw new Error(`catalog: unknown task kind "${t.kind}" in ${t.id}`);
        if (t.subj !== 'all' && !subjectIds.includes(t.subj)) throw new Error(`catalog: unknown subject "${t.subj}" in ${t.id}`);
        if (t.opt !== undefined && t.opt !== true) throw new Error(`catalog: unexpected opt value in ${t.id}`);
        if (t.lesson) lessonTask[t.lesson] = t.id;
        tasks.push({
          id: t.id, date: d.date, slotIndex, order,
          subjectId: t.subj === 'all' ? null : t.subj,
          title: t.title, meta: t.meta, kind: t.kind as TaskKind, minutes: t.min,
          lessonId: t.lesson ?? null, optional: t.opt === true,
        });
      });
      return { label: s.t, breakBefore: s.brk === true, taskIds: s.tasks.map((t) => t.id) };
    });
    days.push({
      date: d.date, dow: d.dow, dayNumber: d.dnum, monthName: d.mon,
      phase: d.phase as 'study' | 'final', fixed: [...d.fixed], slots,
    });
  }

  const lessons: Lesson[] = [];
  for (const subjectId of Object.keys(data.lessons)) {
    data.lessons[subjectId]!.forEach((l, order) => {
      if (!LESSON_ORIGINS.includes(l.status)) throw new Error(`catalog: unknown lesson status "${l.status}" in ${l.id}`);
      lessons.push({
        id: l.id, subjectId, title: l.title, meta: l.meta, origin: l.status as LessonOrigin,
        plannedDate: l.date, order,
        parts: [{ index: 1, title: 'الدرس كامل', taskId: lessonTask[l.id] ?? null, understanding: null, note: '' }],
      });
    });
  }

  const evs: ScheduleEvent[] = events.map((e, i) => ({
    id: `ev${i}`, weekday: e.d, hour: e.h, minute: e.m, label: e.l, travelNeeded: e.lv === 1,
  }));

  return { plan: { id: 'plan', examDate: data.exam }, subjects, lessons, tasks, days, events: evs };
}

// Inverse of buildCatalogRecords. Used to PROVE the new records lost nothing:
// rebuildLegacy(records) must deep-equal the original DATA.
export function rebuildLegacy(r: CatalogRecords): { data: LegacyData; events: LegacyEvent[] } {
  const byId = new Map(r.tasks.map((t) => [t.id, t]));
  const subj: Record<string, string> = {};
  [...r.subjects].sort((a, b) => a.order - b.order).forEach((s) => { subj[s.id] = s.name; });

  const days: LegacyDay[] = [...r.days].sort((a, b) => (a.date < b.date ? -1 : 1)).map((d) => ({
    date: d.date, dow: d.dow, dnum: d.dayNumber, mon: d.monthName, fixed: [...d.fixed],
    slots: d.slots.map((s) => {
      const out: LegacySlot = {
        t: s.label,
        tasks: s.taskIds.map((id) => {
          const t = byId.get(id)!;
          const lt: LegacyTask = {
            id: t.id, subj: t.subjectId ?? 'all', title: t.title, meta: t.meta, kind: t.kind,
            min: t.minutes, lesson: t.lessonId,
          };
          if (t.optional) lt.opt = true;
          return lt;
        }),
      };
      if (s.breakBefore) out.brk = true;
      return out;
    }),
    phase: d.phase,
  }));

  const lessons: Record<string, LegacyLesson[]> = {};
  [...r.lessons].sort((a, b) => a.order - b.order).forEach((l) => {
    (lessons[l.subjectId] ??= []).push({ id: l.id, title: l.title, status: l.origin, meta: l.meta, date: l.plannedDate });
  });

  const events: LegacyEvent[] = [...r.events].sort((a, b) => Number(a.id.slice(2)) - Number(b.id.slice(2))).map((e) => ({ d: e.weekday, h: e.hour, m: e.minute, l: e.label, lv: e.travelNeeded ? 1 : 0 }));
  return { data: { subj, days, lessons, exam: r.plan.examDate }, events };
}
