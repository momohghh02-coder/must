import type {
  Completion, Grade, DailyNote, Unmigratable, Warning, Conflict, SectionCounts, MigrationReport, ImportBatch, Check,
} from '../domain/types.ts';
import { SCHEMA_VERSION } from '../domain/types.ts';
import type { Store } from '../storage/store.ts';
import { buildCatalogRecords, type CatalogFile, type CatalogRecords } from './catalog.ts';
import { verifyCatalogInStore, verifyBatch } from './verify.ts';
import { sha256Hex, canonicalStringify, isObj, isValidIsoDate, deepEqual } from './util.ts';

export class LegacyParseError extends Error {}
export class VerificationFailed extends Error {
  checks: Check[];
  constructor(checks: Check[]) {
    super('verification failed: ' + checks.filter((c) => !c.ok).map((c) => c.name).join(', '));
    this.checks = checks;
  }
}

// Legacy localStorage keys (read from the original file by scripts/extract-catalog.mjs).
export const LEGACY_KEYS = { done: 'mostafa-plan-v1', notes: 'mostafa-notes-v1', grades: 'mostafa-grades-v1' } as const;

export { sha256Hex, canonicalStringify, isValidIsoDate } from './util.ts';

// ---------- 1. parse ----------
export interface ParsedInput {
  kind: MigrationReport['sourceKind'];
  raw: Record<string, unknown>; // the parsed input, verbatim
  sections: { done?: unknown; notes?: unknown; grades?: unknown };
  problems: Unmigratable[];
  warnings: Warning[];
}

// Accepts BOTH shapes:
//  (a) the page's own export:        { done, notes, grades }
//  (b) a raw localStorage dump:       { "mostafa-plan-v1": "<json string>", ... }
export function parseLegacyInput(input: unknown): ParsedInput {
  let v = input;
  if (typeof v === 'string') {
    try { v = JSON.parse(v); } catch { throw new LegacyParseError('الملف ليس JSON صالحًا'); }
  }
  if (!isObj(v)) throw new LegacyParseError('شكل غير معروف: المتوقع كائن JSON');
  const problems: Unmigratable[] = [];
  const warnings: Warning[] = [];

  if ('done' in v || 'notes' in v || 'grades' in v) {
    return { kind: 'app-export', raw: v, sections: { done: v.done, notes: v.notes, grades: v.grades }, problems, warnings };
  }
  const keyed = Object.values(LEGACY_KEYS).some((k) => k in v);
  if (!keyed) throw new LegacyParseError('شكل غير معروف: لا يوجد done/notes/grades ولا مفاتيح mostafa-*');

  const sections: ParsedInput['sections'] = {};
  const map: [keyof ParsedInput['sections'], string][] = [
    ['done', LEGACY_KEYS.done], ['notes', LEGACY_KEYS.notes], ['grades', LEGACY_KEYS.grades],
  ];
  for (const [sec, key] of map) {
    if (!(key in v)) continue;
    const val = v[key];
    if (typeof val !== 'string') { sections[sec] = val; continue; }
    try { sections[sec] = JSON.parse(val); }
    catch { problems.push({ kind: 'storage-key', key, reason: 'قيمة المفتاح ليست JSON صالحًا', value: val }); }
  }
  for (const k of Object.keys(v)) {
    if (!(Object.values(LEGACY_KEYS) as string[]).includes(k)) {
      warnings.push({ code: 'unrelated-key', message: `مفتاح غير تابع للمشروع تم تجاهله (محفوظ في النسخة الخام): ${k}`, key: k });
    }
  }
  return { kind: 'localstorage-dump', raw: v, sections, problems, warnings };
}

// ---------- 2. plan (pure: decides what migrates; writes nothing) ----------
export interface MigrationPlan {
  completions: Completion[];
  notes: DailyNote[];
  grades: Grade[];
  unmigratable: Unmigratable[];
  warnings: Warning[];
  counts: MigrationReport['counts'];
}

const zero = (): SectionCounts => ({ input: 0, migrated: 0, ignoredFalse: 0, unmigratable: 0 });

export function planMigration(rec: CatalogRecords, parsed: ParsedInput, batchId: string): MigrationPlan {
  const taskIds = new Set(rec.tasks.map((t) => t.id));
  const subjectIds = new Set(rec.subjects.map((s) => s.id));
  const first = rec.days[0]!.date;
  const last = rec.days[rec.days.length - 1]!.date;
  const plan: MigrationPlan = {
    completions: [], notes: [], grades: [],
    unmigratable: [...parsed.problems], warnings: [...parsed.warnings],
    counts: { done: zero(), notes: zero(), grades: zero() },
  };
  const { done, notes, grades } = parsed.sections;

  // done: { taskId: truthy }  (the old page treated any truthy value as "done")
  if (done !== undefined) {
    const c = plan.counts.done;
    if (!isObj(done)) {
      c.input = 1; c.unmigratable = 1;
      plan.unmigratable.push({ kind: 'done', key: '(done)', reason: 'القسم ليس كائنًا', value: done });
    } else {
      for (const [id, val] of Object.entries(done)) {
        c.input++;
        if (!val) { c.ignoredFalse++; continue; }
        if (!taskIds.has(id)) {
          c.unmigratable++;
          plan.unmigratable.push({ kind: 'done', key: id, reason: 'معرّف مهمة غير موجود في الجدول', value: val });
          continue;
        }
        if (val !== true) plan.warnings.push({ code: 'done-not-true', message: `قيمة الإنجاز ليست true (${JSON.stringify(val)}) واعتُبرت منجزة كما في الصفحة القديمة`, key: id });
        plan.completions.push({ taskId: id, completedAt: null, source: 'legacy-import', batchId });
        c.migrated++;
      }
      if (done['t8']) {
        plan.warnings.push({ code: 't8-maybe-seed', message: 'المهمة t8 مسجّلة منجزة. الصفحة القديمة كانت تعلّمها تلقائيًا عند أول تشغيل، ولا يمكن التمييز بين ذلك وإنجازك الفعلي. لم يُغيَّر شيء.', key: 't8' });
      }
    }
  }

  // notes: { "YYYY-MM-DD": "text" }
  if (notes !== undefined) {
    const c = plan.counts.notes;
    if (!isObj(notes)) {
      c.input = 1; c.unmigratable = 1;
      plan.unmigratable.push({ kind: 'note', key: '(notes)', reason: 'القسم ليس كائنًا', value: notes });
    } else {
      for (const [date, text] of Object.entries(notes)) {
        c.input++;
        if (!isValidIsoDate(date)) { c.unmigratable++; plan.unmigratable.push({ kind: 'note', key: date, reason: 'مفتاح ليس تاريخًا صالحًا YYYY-MM-DD', value: text }); continue; }
        if (typeof text !== 'string') { c.unmigratable++; plan.unmigratable.push({ kind: 'note', key: date, reason: 'نص الملاحظة ليس نصًا', value: text }); continue; }
        if (date < first || date > last) plan.warnings.push({ code: 'note-outside-plan', message: 'ملاحظة بتاريخ خارج فترة الخطة (تم ترحيلها)', key: date });
        plan.notes.push({ date, text, batchId });
        c.migrated++;
      }
    }
  }

  // grades: [{ id, subj, name, score, max, date }]
  if (grades !== undefined) {
    const c = plan.counts.grades;
    if (!Array.isArray(grades)) {
      c.input = 1; c.unmigratable = 1;
      plan.unmigratable.push({ kind: 'grade', key: '(grades)', reason: 'القسم ليس مصفوفة', value: grades });
    } else {
      const seen = new Map<string, number>();
      grades.forEach((g, i) => {
        c.input++;
        const key = `#${i}`;
        const bad = (reason: string) => { c.unmigratable++; plan.unmigratable.push({ kind: 'grade', key, reason, value: g }); };
        if (!isObj(g)) return bad('عنصر الدرجة ليس كائنًا');
        if (typeof g.subj !== 'string' || !subjectIds.has(g.subj)) return bad('مادة غير معروفة');
        if (typeof g.score !== 'number' || !Number.isFinite(g.score) || g.score < 0) return bad('الدرجة ليست رقمًا صالحًا');
        if (typeof g.max !== 'number' || !Number.isFinite(g.max) || g.max <= 0) return bad('إجمالي الدرجات ليس رقمًا صالحًا');
        if (typeof g.name !== 'string') return bad('اسم الاختبار ليس نصًا');
        if (typeof g.date !== 'string') return bad('تاريخ الدرجة مفقود');
        if (g.id !== null && typeof g.id !== 'number' && typeof g.id !== 'string') return bad('معرّف الدرجة غير صالح');
        if (g.score > g.max) plan.warnings.push({ code: 'grade-score-gt-max', message: 'الدرجة أكبر من الإجمالي (تم ترحيلها كما هي)', key });
        let id = `legacy-${g.id}`;
        const n = seen.get(id) ?? 0;
        seen.set(id, n + 1);
        if (n > 0) { id = `${id}-dup${n}`; plan.warnings.push({ code: 'grade-duplicate-id', message: 'معرّف درجة مكرر: حُفظ كلاهما بمعرّف جديد', key }); }
        plan.grades.push({
          id, legacyId: (g.id as number | string | null) ?? null, seq: i, subjectId: g.subj,
          name: g.name, score: g.score, max: g.max, date: g.date, batchId,
        });
        c.migrated++;
      });
    }
  }
  return plan;
}

// ---------- 3. apply (atomic) ----------
export type ImportResult =
  | { status: 'imported'; batchId: string; report: MigrationReport }
  | { status: 'already-imported'; batchId: string; report: MigrationReport };


export async function importLegacy(
  store: Store, catalog: CatalogFile, input: unknown, opts: { now?: () => string } = {},
): Promise<ImportResult> {
  const parsed = parseLegacyInput(input);
  const batchId = await sha256Hex(canonicalStringify(parsed.raw));

  const existing = await store.get('imports', batchId);
  if (existing) return { status: 'already-imported', batchId, report: existing.report };

  const rec = buildCatalogRecords(catalog);
  const plan = planMigration(rec, parsed, batchId);

  return store.transaction(async () => {
    // 3a. make sure the plan catalog is in the store, and identical to the original
    if (!(await store.get('plans', 'plan'))) {
      await store.put('plans', rec.plan);
      for (const s of rec.subjects) await store.put('subjects', s);
      for (const l of rec.lessons) await store.put('lessons', l);
      for (const t of rec.tasks) await store.put('tasks', t);
      for (const d of rec.days) await store.put('days', d);
      for (const e of rec.events) await store.put('events', e);
    }
    const catChecks = await verifyCatalogInStore(store, catalog);
    if (catChecks.some((c) => !c.ok)) throw new VerificationFailed(catChecks);

    // 3b. merge user data. NEVER overwrite or delete: differences become conflicts.
    const conflicts: Conflict[] = [];
    for (const c of plan.completions) {
      if (!(await store.get('completions', c.taskId))) await store.put('completions', c);
    }
    for (const n of plan.notes) {
      const cur = await store.get('notes', n.date);
      if (!cur) await store.put('notes', n);
      else if (cur.text !== n.text) conflicts.push({ kind: 'note', key: n.date, existing: cur.text, incoming: n.text });
    }
    for (const g of plan.grades) {
      const cur = await store.get('grades', g.id);
      if (!cur) await store.put('grades', g);
      else if (!deepEqual({ ...cur, batchId: null }, { ...g, batchId: null })) conflicts.push({ kind: 'grade', key: g.id, existing: cur, incoming: g });
    }

    const report: MigrationReport = {
      sourceKind: parsed.kind, counts: plan.counts, unmigratable: plan.unmigratable,
      warnings: plan.warnings, conflicts, verification: [],
    };
    const batch: ImportBatch = {
      id: batchId, importedAt: (opts.now ?? (() => new Date().toISOString()))(),
      schemaVersion: SCHEMA_VERSION, raw: parsed.raw, report,
    };
    await store.put('imports', batch);

    // 3c. verify. If anything is off the whole transaction rolls back.
    const checks = [...catChecks, ...(await verifyBatch(store, catalog, plan, batchId, conflicts))];
    report.verification = checks;
    if (checks.some((c) => !c.ok)) throw new VerificationFailed(checks);
    await store.put('imports', { ...batch, report });
    return { status: 'imported' as const, batchId, report };
  });
}
