// MINDORA data model, schema v1.
// Scope of v1: exactly what the legacy schedule page holds, plus fields that
// are ready (but empty) for the features in the product vision.
// Rule: nothing here is ever invented. Unknown values are null, never guessed.

export const SCHEMA_VERSION = 1;

export type TaskKind = 'backlog' | 'new' | 'review' | 'final' | 'course' | 'optional';
export type LessonOrigin = 'backlog' | 'new';
export type Understanding = 'understood' | 'needs-practice' | 'needs-explanation';

export interface Subject {
  id: string; // legacy key, e.g. "math"
  name: string;
  order: number;
  color: string | null; // reserved for the design phase
  icon: string | null;
}

// A lesson is split into 1..5 parts. Legacy lessons become ONE part whose
// completion is the legacy task. Completion is never derived from `understanding`.
export interface LessonPart {
  index: number; // 1-based
  title: string;
  taskId: string | null; // the task whose completion completes this part
  understanding: Understanding | null; // null = not assessed (never inferred from a checkbox)
  note: string;
}

export interface Lesson {
  id: string; // legacy id, e.g. "math0"
  subjectId: string;
  title: string;
  meta: string;
  origin: LessonOrigin; // legacy "status": backlog | new
  plannedDate: string; // YYYY-MM-DD
  order: number; // position inside its subject
  parts: LessonPart[];
}

export interface Task {
  id: string; // legacy id, e.g. "t12" (kept forever: progress is keyed by it)
  date: string;
  slotIndex: number;
  order: number; // position inside its slot
  subjectId: string | null; // null = legacy "all"
  title: string;
  meta: string;
  kind: TaskKind;
  minutes: number;
  lessonId: string | null;
  optional: boolean;
}

export interface DaySlot {
  label: string;
  breakBefore: boolean;
  taskIds: string[];
}

export interface Day {
  date: string;
  dow: string;
  dayNumber: number;
  monthName: string;
  phase: 'study' | 'final';
  fixed: string[]; // afternoon fixed lessons, as written in the legacy plan
  slots: DaySlot[];
}

export interface ScheduleEvent {
  id: string;
  weekday: number; // JS getDay(): 0 = Sunday
  hour: number;
  minute: number;
  label: string;
  travelNeeded: boolean;
}

export interface Plan {
  id: string; // "plan"
  examDate: string;
}

export type CompletionSource = 'legacy-import' | 'app';

export interface Completion {
  taskId: string; // primary key
  completedAt: string | null; // legacy data has no timestamps: null = unknown
  source: CompletionSource;
  batchId: string | null;
}

export interface Grade {
  id: string; // "legacy-<id>" for imported rows
  legacyId: number | string | null;
  seq: number; // position in the legacy array (keeps the original order)
  subjectId: string;
  name: string;
  score: number;
  max: number;
  date: string;
  batchId: string | null;
}

export interface DailyNote {
  date: string; // primary key
  text: string;
  batchId: string | null;
}

export type Check = { name: string; ok: boolean; detail: string };

export interface Unmigratable {
  kind: 'done' | 'note' | 'grade' | 'storage-key';
  key: string;
  reason: string;
  value: unknown; // the original value, kept verbatim
}
export interface Warning {
  code: string;
  message: string;
  key?: string;
}
export interface Conflict {
  kind: 'note' | 'grade';
  key: string;
  existing: unknown;
  incoming: unknown;
}
export interface SectionCounts {
  input: number;
  migrated: number;
  ignoredFalse: number;
  unmigratable: number;
}
export interface MigrationReport {
  sourceKind: 'app-export' | 'localstorage-dump';
  counts: { done: SectionCounts; notes: SectionCounts; grades: SectionCounts };
  unmigratable: Unmigratable[];
  warnings: Warning[];
  conflicts: Conflict[];
  verification: Check[];
}

// The untouched input is stored with every import so nothing can ever be lost.
export interface ImportBatch {
  id: string; // sha256 of the canonical raw input
  importedAt: string;
  schemaVersion: number;
  raw: unknown;
  report: MigrationReport;
}
