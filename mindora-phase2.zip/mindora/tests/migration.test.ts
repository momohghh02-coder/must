// Tests use SYNTHETIC backups built in code (clearly TEST-ONLY).
// They are never mixed with the user's real data; the real catalog (data/catalog.json)
// comes from the original file, and the user's real backup is only ever READ.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { MemoryStore } from '../src/storage/store.ts';
import { importLegacy, parseLegacyInput, LegacyParseError, VerificationFailed, LEGACY_KEYS } from '../src/migration/legacy.ts';
import { buildCatalogRecords, rebuildLegacy, type CatalogFile } from '../src/migration/catalog.ts';
import { exportLegacy } from '../src/migration/verify.ts';
import { canonicalStringify } from '../src/migration/util.ts';

const here = new URL('..', import.meta.url).pathname;
const catalog: CatalogFile = JSON.parse(readFileSync(here + 'data/catalog.json', 'utf8'));
const manifest = JSON.parse(readFileSync(here + 'data/source-manifest.json', 'utf8'));
const fixedNow = () => '2026-11-07T00:00:00.000Z';

const allTaskIds = catalog.data.days.flatMap((d) => d.slots.flatMap((s) => s.tasks.map((t) => t.id)));

// TEST-ONLY synthetic backup
const syntheticBackup = () => ({
  done: { t1: true, t2: true, t3: true, t50: true, t325: true },
  notes: { '2026-11-03': 'سؤال عن الأعداد المركبة\nسطر ثاني ✓', '2026-11-07': '' },
  grades: [
    { id: 1762500000001, subj: 'math', name: 'اختبار 1', score: 18, max: 20, date: '2026-11-05' },
    { id: 1762500000002, subj: 'arabic', name: 'بلاغة', score: 7.5, max: 10, date: '2026-11-06' },
  ],
});

test('catalog: counts match the manifest extracted from the original file', () => {
  const r = buildCatalogRecords(catalog);
  assert.equal(r.subjects.length, manifest.counts.subjects);
  assert.equal(r.days.length, manifest.counts.days);
  assert.equal(r.tasks.length, manifest.counts.tasks);
  assert.equal(r.lessons.length, manifest.counts.lessons);
  assert.equal(r.events.length, manifest.counts.events);
  assert.equal(r.days.reduce((n, d) => n + d.slots.length, 0), manifest.counts.slots);
  assert.equal(r.days.reduce((n, d) => n + d.fixed.length, 0), manifest.counts.fixedEntries);
  assert.equal(r.plan.examDate, manifest.examDate);
  assert.deepEqual(LEGACY_KEYS, manifest.storageKeys);
});

test('catalog: normalized records rebuild EXACTLY to the original DATA (lossless)', () => {
  const back = rebuildLegacy(buildCatalogRecords(catalog));
  assert.deepEqual(back.data, catalog.data);
  assert.deepEqual(back.events, catalog.events);
});

test('catalog: lessons are never marked as understood by default', () => {
  const r = buildCatalogRecords(catalog);
  assert.ok(r.lessons.every((l) => l.parts.length === 1 && l.parts[0]!.understanding === null));
});

test('original file is untouched (sha256 equals the manifest)', { skip: !existsSync(here + 'legacy/mostafa-schedule.html') }, () => {
  const sha = createHash('sha256').update(readFileSync(here + 'legacy/mostafa-schedule.html')).digest('hex');
  assert.equal(sha, manifest.source.sha256);
});

test('import (app-export shape): everything lands and round-trips back identical', async () => {
  const store = new MemoryStore();
  const input = syntheticBackup();
  const res = await importLegacy(store, catalog, input, { now: fixedNow });
  assert.equal(res.status, 'imported');
  assert.ok(res.report.verification.every((c) => c.ok), JSON.stringify(res.report.verification));
  assert.deepEqual(res.report.counts.done, { input: 5, migrated: 5, ignoredFalse: 0, unmigratable: 0 });
  assert.deepEqual(res.report.counts.notes, { input: 2, migrated: 2, ignoredFalse: 0, unmigratable: 0 });
  assert.deepEqual(res.report.counts.grades, { input: 2, migrated: 2, ignoredFalse: 0, unmigratable: 0 });
  assert.equal(res.report.unmigratable.length, 0);
  assert.deepEqual(await exportLegacy(store), input); // before == after
  const comps = await store.all('completions');
  assert.ok(comps.every((c) => c.completedAt === null && c.source === 'legacy-import')); // no invented timestamps
});

test('import (localStorage dump shape, as the Console snippet produced) is accepted', async () => {
  const b = syntheticBackup();
  const dump = {
    [LEGACY_KEYS.done]: JSON.stringify(b.done),
    [LEGACY_KEYS.notes]: JSON.stringify(b.notes),
    [LEGACY_KEYS.grades]: JSON.stringify(b.grades),
    'some-other-key': 'x',
  };
  const store = new MemoryStore();
  const res = await importLegacy(store, catalog, JSON.stringify(dump), { now: fixedNow });
  assert.equal(res.report.sourceKind, 'localstorage-dump');
  assert.deepEqual(await exportLegacy(store), b);
  assert.ok(res.report.warnings.some((w) => w.code === 'unrelated-key'));
});

test('nothing is silently dropped: bad entries are reported with their original value', async () => {
  const input = {
    done: { t1: true, t999: true, t2: false, t3: 1 },
    notes: { '2026-11-03': 'ok', 'not-a-date': 'x', '2026-11-04': 42 },
    grades: [
      { id: 1, subj: 'math', name: 'a', score: 5, max: 10, date: '2026-11-05' },
      { id: 2, subj: 'physics', name: 'b', score: 5, max: 10, date: '2026-11-05' },
      { id: 3, subj: 'math', name: 'c', score: 'x', max: 10, date: '2026-11-05' },
      { id: 4, subj: 'math', name: 'd', score: 12, max: 10, date: '2026-11-05' },
    ],
  };
  const store = new MemoryStore();
  const res = await importLegacy(store, catalog, input, { now: fixedNow });
  const c = res.report.counts;
  assert.deepEqual(c.done, { input: 4, migrated: 2, ignoredFalse: 1, unmigratable: 1 });
  assert.deepEqual(c.notes, { input: 3, migrated: 1, ignoredFalse: 0, unmigratable: 2 });
  assert.deepEqual(c.grades, { input: 4, migrated: 2, ignoredFalse: 0, unmigratable: 2 });
  assert.equal(res.report.unmigratable.length, 5);
  assert.ok(res.report.unmigratable.some((u) => u.key === 't999' && u.value === true));
  assert.ok(res.report.warnings.some((w) => w.code === 'grade-score-gt-max'));
  assert.ok(res.report.warnings.some((w) => w.code === 'done-not-true'));
  const batch = (await store.all('imports'))[0]!;
  assert.deepEqual(batch.raw, input); // the full original input is kept verbatim
});

test('t8 in the backup produces a warning and is NOT changed', async () => {
  const store = new MemoryStore();
  const res = await importLegacy(store, catalog, { done: { t8: true } }, { now: fixedNow });
  assert.ok(res.report.warnings.some((w) => w.code === 't8-maybe-seed'));
  assert.ok(await store.get('completions', 't8'));
});

test('importing the same backup twice does not duplicate anything', async () => {
  const store = new MemoryStore();
  const a = await importLegacy(store, catalog, syntheticBackup(), { now: fixedNow });
  const before = canonicalStringify([...store.tables].map(([k, m]) => [k, [...m]]));
  const b = await importLegacy(store, catalog, syntheticBackup(), { now: fixedNow });
  assert.equal(a.status, 'imported');
  assert.equal(b.status, 'already-imported');
  assert.equal(canonicalStringify([...store.tables].map(([k, m]) => [k, [...m]])), before);
});

test('a later backup never overwrites existing notes: it reports a conflict instead', async () => {
  const store = new MemoryStore();
  await importLegacy(store, catalog, { notes: { '2026-11-03': 'النسخة الأولى' } }, { now: fixedNow });
  const res = await importLegacy(store, catalog, { notes: { '2026-11-03': 'نسخة مختلفة' }, done: { t1: true } }, { now: fixedNow });
  assert.equal(res.report.conflicts.length, 1);
  assert.equal((await store.get('notes', '2026-11-03'))!.text, 'النسخة الأولى');
  assert.ok(await store.get('completions', 't1')); // non-conflicting data still merged
});

test('unrecognized input fails loudly and writes nothing', async () => {
  const store = new MemoryStore();
  await assert.rejects(() => importLegacy(store, catalog, { hello: 1 }, { now: fixedNow }), LegacyParseError);
  await assert.rejects(() => importLegacy(store, catalog, 'not json', { now: fixedNow }), LegacyParseError);
  assert.equal((await store.all('plans')).length, 0);
  assert.equal((await store.all('tasks')).length, 0);
});

test('a failed verification rolls the whole import back', async () => {
  const store = new MemoryStore();
  const realPut = store.put.bind(store);
  // sabotage: silently drop one completion write so verification must notice
  store.put = (async (table: any, row: any) => {
    if (table === 'completions' && row.taskId === 't2') return;
    return realPut(table, row);
  }) as typeof store.put;
  await assert.rejects(() => importLegacy(store, catalog, { done: { t1: true, t2: true } }, { now: fixedNow }), VerificationFailed);
  assert.equal((await store.all('plans')).length, 0);
  assert.equal((await store.all('completions')).length, 0);
  assert.equal((await store.all('imports')).length, 0);
});

test('every catalog task id can be imported as done (full-plan backup)', async () => {
  const done = Object.fromEntries(allTaskIds.map((id) => [id, true]));
  const store = new MemoryStore();
  const res = await importLegacy(store, catalog, { done }, { now: fixedNow });
  assert.equal(res.report.counts.done.migrated, 325);
  assert.equal(res.report.unmigratable.length, 0);
});

test('parseLegacyInput keeps the raw input verbatim', () => {
  const input = syntheticBackup();
  assert.deepEqual(parseLegacyInput(input).raw, input);
});
